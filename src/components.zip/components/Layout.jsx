import Characters from './characters/Characters'
import FamilyTree from './familytree/FamilyTree'
import Lore from './lore/Lore'
import Timeline from './timeline/Timeline'
import WorldHistory from './worldhistory/WorldHistory'

const SECTIONS = [
  { id: 'characters', label: 'Characters', icon: '👤' },
  { id: 'familytree', label: 'Family Tree', icon: '🌳' },
  { id: 'lore', label: 'Lore', icon: '📖' },
  { id: 'timeline', label: 'Timeline', icon: '⏳' },
  { id: 'worldhistory', label: 'World History', icon: '📜' },
]

export default function Layout({ store, section, setSection }) {
  const content = {
    characters: <Characters store={store} />,
    familytree: <FamilyTree
      characters={store.characters}
      saveCharacter={store.saveCharacter}
      relationships={store.relationships}
      addRelationship={store.addRelationship}
      removeRelationship={store.removeRelationship}
    />,
    lore: <Lore store={store} />,
    timeline: <Timeline store={store} />,
    worldhistory: <WorldHistory store={store} />,
  }

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden">
      <aside className="w-52 bg-slate-900 border-r border-slate-700/60 flex flex-col flex-shrink-0">
        <div className="px-4 py-4 border-b border-slate-700/60">
          <h1 className="text-amber-500 font-bold text-base tracking-tight">NovelForge</h1>
          <p className="text-slate-400 text-xs mt-0.5 truncate" title={store.activeNovel.title}>
            {store.activeNovel.title}
          </p>
        </div>

        <nav className="flex-1 p-2 space-y-0.5">
          {SECTIONS.map(s => (
            <button
              key={s.id}
              onClick={() => setSection(s.id)}
              className={`w-full text-left px-3 py-2 rounded text-sm flex items-center gap-2.5 transition-colors ${
                section === s.id
                  ? 'bg-amber-500/15 text-amber-400 font-medium'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800'
              }`}
            >
              <span className="text-base leading-none">{s.icon}</span>
              {s.label}
            </button>
          ))}
        </nav>

        <div className="p-2 border-t border-slate-700/60">
          <button
            onClick={() => store.setActiveNovelId(null)}
            className="w-full text-left px-3 py-2 rounded text-xs text-slate-500 hover:text-slate-300 hover:bg-slate-800 transition-colors"
          >
            ← All novels
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-hidden">
        {content[section]}
      </main>
    </div>
  )
}
