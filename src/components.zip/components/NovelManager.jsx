import { useState } from 'react'

export default function NovelManager({ store }) {
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ title: '', description: '' })

  const handleCreate = (e) => {
    e.preventDefault()
    if (!form.title.trim()) return
    store.addNovel(form)
    setForm({ title: '', description: '' })
    setShowForm(false)
  }

  const handleDelete = (id) => {
    if (confirm('Delete this novel and all its content? This cannot be undone.')) {
      store.deleteNovel(id)
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-8">
      <div className="w-full max-w-xl">
        <div className="mb-10 text-center">
          <h1 className="text-4xl font-bold text-amber-500 mb-2 tracking-tight">NovelForge</h1>
          <p className="text-slate-400 text-sm">Your world. Your story.</p>
        </div>

        {store.novels.length > 0 && (
          <div className="mb-6 space-y-2">
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-3">Your novels</p>
            {store.novels.map(n => (
              <div
                key={n.id}
                className="flex items-center justify-between bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 group"
              >
                <div className="min-w-0">
                  <div className="font-medium truncate">{n.title}</div>
                  {n.description && (
                    <div className="text-sm text-slate-400 mt-0.5 truncate">{n.description}</div>
                  )}
                </div>
                <div className="flex gap-2 ml-3 flex-shrink-0">
                  <button
                    onClick={() => store.setActiveNovelId(n.id)}
                    className="text-sm px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold rounded transition-colors"
                  >
                    Open
                  </button>
                  <button
                    onClick={() => handleDelete(n.id)}
                    className="text-sm px-2 py-1.5 text-slate-500 hover:text-red-400 rounded transition-colors opacity-0 group-hover:opacity-100"
                    title="Delete novel"
                  >
                    ✕
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {showForm ? (
          <form onSubmit={handleCreate} className="bg-slate-800 border border-slate-700 rounded-lg p-5 space-y-3">
            <input
              autoFocus
              placeholder="Novel title *"
              value={form.title}
              onChange={e => setForm(p => ({ ...p, title: e.target.value }))}
              className="w-full bg-slate-900 border border-slate-600 rounded px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-amber-500"
              required
            />
            <textarea
              placeholder="Short description (optional)"
              value={form.description}
              onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
              rows={2}
              className="w-full bg-slate-900 border border-slate-600 rounded px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-amber-500 resize-none"
            />
            <div className="flex gap-2">
              <button
                type="submit"
                className="flex-1 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold rounded text-sm transition-colors"
              >
                Create Novel
              </button>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-4 py-2 text-slate-400 hover:text-slate-100 text-sm transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        ) : (
          <button
            onClick={() => setShowForm(true)}
            className="w-full py-3 border-2 border-dashed border-slate-700 hover:border-amber-500/50 text-slate-500 hover:text-amber-400 rounded-lg text-sm transition-colors"
          >
            + Create new novel
          </button>
        )}
      </div>
    </div>
  )
}
