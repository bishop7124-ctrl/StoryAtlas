import { useState, useRef } from 'react'
import Modal from '../shared/Modal'
import { REL_TYPES } from '../familytree/FamilyTree'

const ROLES = ['Protagonist', 'Antagonist', 'Supporting', 'Minor', 'Mentioned']

const INPUT = 'w-full bg-slate-900 border border-slate-600 rounded px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-amber-500 placeholder:text-slate-600'
const LABEL = 'block text-xs text-slate-400 mb-1.5'

// All spouses, checking both directions for robustness
function resolveSpouseIds(char, allChars) {
  const ids = new Set(char.spouseIds || [])
  allChars.forEach(c => { if ((c.spouseIds || []).includes(char.id)) ids.add(c.id) })
  return [...ids]
}

function TagInput({ value, onChange }) {
  const [input, setInput] = useState('')
  const add = (e) => {
    if ((e.key === 'Enter' || e.key === ',') && input.trim()) {
      e.preventDefault()
      const tag = input.trim().replace(/,$/, '')
      if (tag && !value.includes(tag)) onChange([...value, tag])
      setInput('')
    }
  }
  return (
    <div>
      {value.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-1.5">
          {value.map(t => (
            <span key={t} className="inline-flex items-center gap-1 bg-slate-700 rounded px-2 py-0.5 text-xs text-slate-300">
              {t}
              <button type="button" onClick={() => onChange(value.filter(x => x !== t))} className="text-slate-500 hover:text-slate-100">×</button>
            </span>
          ))}
        </div>
      )}
      <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={add} placeholder="Type a tag and press Enter" className={INPUT} />
    </div>
  )
}

function AvatarCircle({ avatarUrl, name, size = 40 }) {
  if (avatarUrl) {
    return (
      <img
        src={avatarUrl}
        alt={name}
        style={{ width: size, height: size }}
        className="rounded-full object-cover flex-shrink-0"
      />
    )
  }
  return (
    <div
      style={{ width: size, height: size, fontSize: size * 0.38 }}
      className="rounded-full bg-slate-700 flex items-center justify-center font-bold text-slate-300 flex-shrink-0"
    >
      {name?.charAt(0)?.toUpperCase() || '?'}
    </div>
  )
}

function CharacterForm({ initial, characters, onSave, onCancel }) {
  const initialChildIds = characters
    .filter(c => (c.parentIds || []).includes(initial?.id || '__none__'))
    .map(c => c.id)

  const [form, setForm] = useState({
    name: initial?.name ?? '',
    aka: initial?.aka ?? '',
    role: initial?.role ?? '',
    bio: initial?.bio ?? '',
    birthDate: initial?.birthDate ?? '',
    deathDate: initial?.deathDate ?? '',
    familyGroup: initial?.familyGroup ?? '',
    tags: initial?.tags ?? [],
    parentIds: initial?.parentIds ?? [],
    spouseIds: initial?.spouseIds ?? [],
    _childIds: initialChildIds,
    avatarUrl: initial?.avatarUrl ?? '',
  })

  const fileRef = useRef()
  const field = (key) => (e) => setForm(p => ({ ...p, [key]: e.target.value }))
  const toggle = (key, id) => setForm(p => ({
    ...p,
    [key]: p[key].includes(id) ? p[key].filter(x => x !== id) : [...p[key], id],
  }))

  const handleAvatar = (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = (ev) => setForm(p => ({ ...p, avatarUrl: ev.target.result }))
    reader.readAsDataURL(file)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!form.name.trim()) return
    onSave(form)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Avatar */}
      <div className="flex items-center gap-4">
        <AvatarCircle avatarUrl={form.avatarUrl} name={form.name || '?'} size={64} />
        <div className="flex-1">
          <label className={LABEL}>Portrait photo</label>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            onChange={handleAvatar}
            className="hidden"
          />
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="text-xs px-3 py-1.5 border border-slate-600 hover:border-amber-500 text-slate-400 hover:text-amber-400 rounded transition-colors"
            >
              Upload image
            </button>
            {form.avatarUrl && (
              <button
                type="button"
                onClick={() => setForm(p => ({ ...p, avatarUrl: '' }))}
                className="text-xs px-3 py-1.5 border border-slate-700 hover:border-red-500 text-slate-500 hover:text-red-400 rounded transition-colors"
              >
                Remove
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="col-span-2">
          <label className={LABEL}>Name *</label>
          <input value={form.name} onChange={field('name')} className={INPUT} required />
        </div>
        <div>
          <label className={LABEL}>Also known as</label>
          <input value={form.aka} onChange={field('aka')} placeholder="Nicknames, titles…" className={INPUT} />
        </div>
        <div>
          <label className={LABEL}>Role</label>
          <select value={form.role} onChange={field('role')} className={INPUT}>
            <option value="">— Select —</option>
            {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div>
          <label className={LABEL}>Birth date</label>
          <input value={form.birthDate} onChange={field('birthDate')} placeholder="e.g. Year 42, Third Age" className={INPUT} />
        </div>
        <div>
          <label className={LABEL}>Death date</label>
          <input value={form.deathDate} onChange={field('deathDate')} placeholder="Leave blank if alive" className={INPUT} />
        </div>
        <div className="col-span-2">
          <label className={LABEL}>Family / Clan (for tree grouping)</label>
          <input value={form.familyGroup} onChange={field('familyGroup')} placeholder="e.g. House Stark, The Doe Family…" className={INPUT} />
        </div>
      </div>

      <div>
        <label className={LABEL}>Biography</label>
        <textarea value={form.bio} onChange={field('bio')} rows={4} className={INPUT + ' resize-none'} placeholder="Background, personality, history…" />
      </div>

      <div>
        <label className={LABEL}>Tags</label>
        <TagInput value={form.tags} onChange={tags => setForm(p => ({ ...p, tags }))} />
      </div>

      {characters.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className={LABEL}>Parents</label>
            <div className="max-h-36 overflow-y-auto bg-slate-900 border border-slate-600 rounded p-2 space-y-1.5">
              {characters.map(c => (
                <label key={c.id} className="flex items-center gap-2 text-xs cursor-pointer text-slate-300 hover:text-slate-100">
                  <input type="checkbox" checked={form.parentIds.includes(c.id)} onChange={() => toggle('parentIds', c.id)} className="accent-amber-500" />
                  <span className="truncate">{c.name}</span>
                </label>
              ))}
            </div>
          </div>
          <div>
            <label className={LABEL}>Children</label>
            <div className="max-h-36 overflow-y-auto bg-slate-900 border border-slate-600 rounded p-2 space-y-1.5">
              {characters.map(c => (
                <label key={c.id} className="flex items-center gap-2 text-xs cursor-pointer text-slate-300 hover:text-slate-100">
                  <input type="checkbox" checked={form._childIds.includes(c.id)} onChange={() => toggle('_childIds', c.id)} className="accent-amber-500" />
                  <span className="truncate">{c.name}</span>
                </label>
              ))}
            </div>
          </div>
          <div>
            <label className={LABEL}>Spouses / Partners</label>
            <div className="max-h-36 overflow-y-auto bg-slate-900 border border-slate-600 rounded p-2 space-y-1.5">
              {characters.map(c => (
                <label key={c.id} className="flex items-center gap-2 text-xs cursor-pointer text-slate-300 hover:text-slate-100">
                  <input type="checkbox" checked={form.spouseIds.includes(c.id)} onChange={() => toggle('spouseIds', c.id)} className="accent-amber-500" />
                  <span className="truncate">{c.name}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="flex gap-2 pt-1 border-t border-slate-700">
        <button type="submit" className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold rounded text-sm transition-colors">
          Save
        </button>
        <button type="button" onClick={onCancel} className="px-4 py-2 text-slate-400 hover:text-slate-200 text-sm transition-colors">
          Cancel
        </button>
      </div>
    </form>
  )
}

function CharacterDetail({ character, characters, relationships, onEdit, onDelete }) {
  const find = (id) => characters.find(c => c.id === id)
  const children = characters.filter(c => (c.parentIds || []).includes(character.id))
  const spouseIds = resolveSpouseIds(character, characters)

  // Non-structural relationships from the relationships store
  const myRels = (relationships || []).filter(r =>
    (r.fromId === character.id || r.toId === character.id) &&
    r.type !== 'spouse' && r.type !== 'partner'
  )
  const relsByType = {}
  myRels.forEach(r => {
    if (!relsByType[r.type]) relsByType[r.type] = []
    const otherId = r.fromId === character.id ? r.toId : r.fromId
    const other = find(otherId)
    if (other) relsByType[r.type].push(other)
  })

  return (
    <div className="max-w-2xl">
      {/* Header: avatar + name */}
      <div className="flex items-start gap-4 mb-5">
        <AvatarCircle avatarUrl={character.avatarUrl} name={character.name} size={80} />
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-2xl font-bold text-slate-100 leading-tight">{character.name}</h2>
              {character.aka && <p className="text-slate-400 text-sm mt-0.5">"{character.aka}"</p>}
              <div className="flex flex-wrap gap-1.5 mt-2">
                {character.role && (
                  <span className="px-2.5 py-0.5 bg-amber-500/20 text-amber-400 text-xs rounded-full font-medium">
                    {character.role}
                  </span>
                )}
                {character.familyGroup && (
                  <span className="px-2.5 py-0.5 bg-slate-700 text-slate-300 text-xs rounded-full">
                    {character.familyGroup}
                  </span>
                )}
              </div>
            </div>
            <div className="flex gap-2 flex-shrink-0 ml-4">
              <button onClick={onEdit} className="text-sm px-3 py-1.5 border border-slate-600 hover:border-amber-500 text-slate-300 hover:text-amber-400 rounded transition-colors">
                Edit
              </button>
              <button onClick={onDelete} className="text-sm px-3 py-1.5 border border-slate-700 hover:border-red-500 text-slate-500 hover:text-red-400 rounded transition-colors">
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>

      {(character.birthDate || character.deathDate) && (
        <div className="flex gap-6 mb-4 p-3 bg-slate-800/40 rounded-lg border border-slate-700/40">
          {character.birthDate && (
            <div>
              <div className="text-xs text-slate-500 uppercase tracking-wider mb-0.5">Born</div>
              <div className="text-sm text-slate-200">{character.birthDate}</div>
            </div>
          )}
          {character.deathDate && (
            <div>
              <div className="text-xs text-slate-500 uppercase tracking-wider mb-0.5">Died</div>
              <div className="text-sm text-slate-200">{character.deathDate}</div>
            </div>
          )}
        </div>
      )}

      {character.bio && (
        <div className="mb-5">
          <div className="text-xs text-slate-500 uppercase tracking-wider mb-2">Biography</div>
          <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap">{character.bio}</p>
        </div>
      )}

      {character.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-5">
          {character.tags.map(t => (
            <span key={t} className="bg-slate-800 border border-slate-700 text-slate-400 text-xs px-2 py-0.5 rounded">{t}</span>
          ))}
        </div>
      )}

      {/* Family relationships */}
      {(character.parentIds?.length > 0 || spouseIds.length > 0 || children.length > 0) && (
        <div className="border-t border-slate-700/60 pt-4 space-y-4">
          {character.parentIds?.length > 0 && (
            <div>
              <div className="text-xs text-slate-500 uppercase tracking-wider mb-2">Parents</div>
              <div className="flex flex-wrap gap-2">
                {character.parentIds.map(id => {
                  const p = find(id)
                  return p ? (
                    <div key={id} className="flex items-center gap-2 bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5">
                      <AvatarCircle avatarUrl={p.avatarUrl} name={p.name} size={20} />
                      <span className="text-sm text-slate-300">{p.name}</span>
                    </div>
                  ) : null
                })}
              </div>
            </div>
          )}
          {spouseIds.length > 0 && (
            <div>
              <div className="text-xs text-slate-500 uppercase tracking-wider mb-2">Spouses / Partners</div>
              <div className="flex flex-wrap gap-2">
                {spouseIds.map(id => {
                  const s = find(id)
                  return s ? (
                    <div key={id} className="flex items-center gap-2 bg-slate-800 border border-amber-500/20 rounded-lg px-3 py-1.5">
                      <AvatarCircle avatarUrl={s.avatarUrl} name={s.name} size={20} />
                      <span className="text-sm text-amber-300/80">{s.name}</span>
                    </div>
                  ) : null
                })}
              </div>
            </div>
          )}
          {children.length > 0 && (
            <div>
              <div className="text-xs text-slate-500 uppercase tracking-wider mb-2">Children</div>
              <div className="flex flex-wrap gap-2">
                {children.map(c => (
                  <div key={c.id} className="flex items-center gap-2 bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5">
                    <AvatarCircle avatarUrl={c.avatarUrl} name={c.name} size={20} />
                    <span className="text-sm text-slate-300">{c.name}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Extra relationship types from FamilyTree */}
      {Object.keys(relsByType).length > 0 && (
        <div className="border-t border-slate-700/60 pt-4 mt-4 space-y-4">
          {Object.entries(relsByType).map(([type, chars]) => {
            const rt = REL_TYPES.find(r => r.id === type)
            if (!rt) return null
            return (
              <div key={type}>
                <div className="text-xs uppercase tracking-wider mb-2" style={{ color: rt.color + 'cc' }}>{rt.label}</div>
                <div className="flex flex-wrap gap-2">
                  {chars.map(c => (
                    <div key={c.id} className="flex items-center gap-2 bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5">
                      <AvatarCircle avatarUrl={c.avatarUrl} name={c.name} size={20} />
                      <span className="text-sm text-slate-300">{c.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

export default function Characters({ store }) {
  const { characters, saveCharacter, deleteCharacter, relationships = [] } = store
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const [editTarget, setEditTarget] = useState(null)

  const filtered = characters.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    (c.role || '').toLowerCase().includes(search.toLowerCase()) ||
    (c.familyGroup || '').toLowerCase().includes(search.toLowerCase()) ||
    (c.tags || []).some(t => t.toLowerCase().includes(search.toLowerCase()))
  )

  const openCreate = () => { setEditTarget(null); setShowForm(true) }
  const openEdit = (char) => { setEditTarget(char); setShowForm(true) }
  const closeForm = () => { setShowForm(false); setEditTarget(null) }

  const handleSave = (data) => {
    const { id } = saveCharacter(data, editTarget?.id || null)
    if (!editTarget) setSelected(characters.find(c => c.id === id) || { id })
    closeForm()
  }

  const handleDelete = (id) => {
    if (!confirm('Delete this character?')) return
    deleteCharacter(id)
    if (selected?.id === id) setSelected(null)
  }

  const liveSelected = selected ? characters.find(c => c.id === selected.id) : null

  return (
    <div className="flex h-full">
      {/* Sidebar list */}
      <div className="w-60 bg-slate-900/40 border-r border-slate-700/60 flex flex-col flex-shrink-0">
        <div className="p-3 border-b border-slate-700/60 space-y-2">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-200">Characters</h2>
            <button onClick={openCreate} className="text-xs text-amber-400 hover:text-amber-300 border border-amber-500/30 hover:border-amber-400 px-2 py-1 rounded transition-colors">
              + New
            </button>
          </div>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search…"
            className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-amber-500 placeholder:text-slate-600"
          />
        </div>
        <div className="flex-1 overflow-y-auto">
          {filtered.length === 0 && (
            <p className="text-slate-600 text-xs p-4 text-center">
              {characters.length === 0 ? 'No characters yet.' : 'No matches.'}
            </p>
          )}
          {filtered.map(c => (
            <button
              key={c.id}
              onClick={() => setSelected(c)}
              className={`w-full text-left px-3 py-2.5 border-b border-slate-800/40 hover:bg-slate-800/60 transition-colors flex items-center gap-2.5 ${
                liveSelected?.id === c.id ? 'bg-slate-800/60 border-l-2 border-l-amber-500 pl-2.5' : ''
              }`}
            >
              <AvatarCircle avatarUrl={c.avatarUrl} name={c.name} size={28} />
              <div className="min-w-0">
                <div className="text-sm font-medium text-slate-200 truncate">{c.name}</div>
                <div className="text-xs text-slate-500 truncate">{c.role || (c.familyGroup ? c.familyGroup : '—')}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Detail panel */}
      <div className="flex-1 overflow-y-auto p-6">
        {!liveSelected ? (
          <div className="h-full flex items-center justify-center text-slate-700">
            <div className="text-center">
              <div className="text-5xl mb-3 opacity-60">👤</div>
              <p className="text-sm">Select a character or create one</p>
            </div>
          </div>
        ) : (
          <CharacterDetail
            character={liveSelected}
            characters={characters}
            relationships={relationships}
            onEdit={() => openEdit(liveSelected)}
            onDelete={() => handleDelete(liveSelected.id)}
          />
        )}
      </div>

      {showForm && (
        <Modal title={editTarget ? `Edit — ${editTarget.name}` : 'New Character'} onClose={closeForm} wide>
          <CharacterForm
            initial={editTarget}
            characters={characters.filter(c => c.id !== editTarget?.id)}
            onSave={handleSave}
            onCancel={closeForm}
          />
        </Modal>
      )}
    </div>
  )
}
