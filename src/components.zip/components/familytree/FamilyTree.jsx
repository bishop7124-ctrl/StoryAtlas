import { useState, useMemo, useRef, useEffect } from "react";

// ── 1. Layout & Styling Constants ──────────────────────────
const NW = 160;   const NH = 64;    const HG = 56;    
const SG = 20;    const VG = 96;    const GG = 88;    const PAD = 100; 

export const REL_TYPES = [
  { id: "spouse",  label: "Spouse",  color: "#f59e0b", family: true  },
  { id: "partner", label: "Partner", color: "#f59e0b", family: true  },
  { id: "child",   label: "Child",   color: "#64748b", family: true  },
  { id: "parent",  label: "Parent",  color: "#64748b", family: true  },
  { id: "ally",    label: "Ally",    color: "#22c55e", family: false },
  { id: "rival",   label: "Rival",   color: "#ef4444", family: false },
  { id: "mentor",  label: "Mentor",  color: "#8b5cf6", family: false },
  { id: "other",   label: "Other",   color: "#94a3b8", family: false },
];

// Defined at the top so functions below can access them
const LINK_TYPES = REL_TYPES.filter(r => !r.family);
const STRUCTURAL = new Set(["spouse", "partner", "child", "parent"]);

const PALETTE = ["#2563eb", "#059669", "#d97706", "#dc2626", "#7c3aed", "#0891b2", "#c2410c", "#be185d", "#0d9488", "#65a30d", "#9333ea", "#e11d48"];

function loadPref(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
  catch { return fallback; }
}

// ── 2. Layout Logic Functions ──────────────────────────────
function buildLayout(chars, dragOffsets = {}, groupOffsets = {}) {
  const gMap = new Map();
  for (const c of chars) {
    const g = c.familyGroup?.trim() || "(ungrouped)";
    if (!gMap.has(g)) gMap.set(g, []);
    gMap.get(g).push(c);
  }

  const positions = new Map();
  const spousePairs = new Map();
  const groupMeta = [];
  let oy = PAD;

  for (const [gName, members] of gMap) {
    const cMap = new Map(members.map(c => [c.id, c]));
    const sMap = (function buildSpouseMap(chars) {
      const m = new Map();
      for (const c of chars) {
        if (!m.has(c.id)) m.set(c.id, new Set());
        for (const sid of c.spouseIds || []) {
          m.get(c.id).add(sid);
          if (!m.has(sid)) m.set(sid, new Set());
          m.get(sid).add(c.id);
        }
      }
      return m;
    })(members);

    const lvs = (function computeLevels(chars, charMap, spouseMap) {
      const lv = new Map();
      for (const c of chars) if (!(c.parentIds || []).some(p => charMap.has(p))) lv.set(c.id, 0);
      let changed = true, guard = 0;
      while (changed && guard++ < 100) {
        changed = false;
        for (const c of chars) {
          const pLvs = (c.parentIds || []).filter(p => charMap.has(p)).map(p => lv.get(p)).filter(v => v != null);
          if (!pLvs.length) continue;
          const next = Math.max(...pLvs) + 1;
          if ((lv.get(c.id) ?? -1) < next) { lv.set(c.id, next); changed = true; }
        }
      }
      return lv;
    })(members, cMap, sMap);

    const minLv = Math.min(...lvs.values()) || 0;
    const byLv = new Map();
    for (const c of members) {
      const nl = lvs.get(c.id) - minLv;
      if (!byLv.has(nl)) byLv.set(nl, []);
      byLv.get(nl).push(c.id);
    }

    const sortedLvs = [...byLv.keys()].sort((a, b) => a - b);
    const slotsForLevel = (ids, smap) => {
      const used = new Set(), slots = [];
      for (const id of ids) {
        if (used.has(id)) continue;
        used.add(id);
        const mate = [...(smap.get(id) || [])].find(s => ids.includes(s) && !used.has(s));
        if (mate) { slots.push([id, mate]); used.add(mate); }
        else slots.push([id]);
      }
      return slots;
    };

    const gOff = groupOffsets[gName] || { x: 0, y: 0 };
    const maxW = Math.max(...sortedLvs.map(lv => {
      const slots = slotsForLevel(byLv.get(lv), sMap);
      return slots.reduce((a, s) => a + (s.length === 2 ? NW * 2 + SG : NW), 0) + HG * Math.max(slots.length - 1, 0);
    }), 100);

    for (const lv of sortedLvs) {
      const slots = slotsForLevel(byLv.get(lv), sMap);
      const ry = oy + lv * (NH + VG);
      const rw = slots.reduce((a, s) => a + (s.length === 2 ? NW * 2 + SG : NW), 0) + HG * Math.max(slots.length - 1, 0);
      let x = PAD + (maxW - rw) / 2;

      for (const slot of slots) {
        slot.forEach((id, idx) => {
          const charOff = dragOffsets[id] || { x: 0, y: 0 };
          const finalX = (idx === 0 ? x : x + NW + SG) + charOff.x + gOff.x;
          const finalY = ry + charOff.y + gOff.y;
          positions.set(id, { x: finalX, y: finalY });
          if (slot.length === 2) {
            spousePairs.set(slot[0], slot[1]);
            spousePairs.set(slot[1], slot[0]);
          }
        });
        x += (slot.length === 2 ? NW * 2 + SG : NW) + HG;
      }
    }

    const maxNl = Math.max(...sortedLvs, 0);
    const gH = (maxNl + 1) * (NH + VG) - VG;
    groupMeta.push({ name: gName, x: gOff.x, y: oy + gOff.y, w: maxW + PAD * 2, h: gH });
    oy += gH + GG;
  }

  return { positions, spousePairs, groupMeta };
}

function buildEdges(chars, positions, spousePairs, relationships) {
  const edges = [];
  const drawnSpouses = new Set();
  for (const [a, b] of spousePairs) {
    const key = [a, b].sort().join("|");
    if (drawnSpouses.has(key)) continue;
    drawnSpouses.add(key);
    const pa = positions.get(a), pb = positions.get(b);
    if (!pa || !pb) continue;
    edges.push({ type: "spouse", x1: pa.x + NW, y1: pa.y + NH / 2, x2: pb.x, y2: pb.y + NH / 2 });
  }
  const fams = new Map();
  for (const c of chars) {
    const kp = (c.parentIds || []).filter(p => positions.has(p)).sort();
    if (!kp.length) continue;
    const key = kp.join("|");
    if (!fams.has(key)) fams.set(key, { parents: kp, children: [] });
    fams.get(key).children.push(c.id);
  }
  for (const { parents, children } of fams.values()) {
    const pPos = parents.map(id => positions.get(id)).filter(Boolean);
    const cPos = children.map(id => positions.get(id)).filter(Boolean);
    if (!pPos.length || !cPos.length) continue;
    const pBotY = Math.max(...pPos.map(p => p.y + NH));
    const cTopY = Math.min(...cPos.map(p => p.y));
    const midY = pBotY + (cTopY - pBotY) * 0.45;
    const cBarY = cTopY - (cTopY - pBotY) * 0.15;
    const pCxs = pPos.map(p => p.x + NW / 2);
    const cCxs = cPos.map(p => p.x + NW / 2);
    const hubX = (Math.min(...pCxs) + Math.max(...pCxs)) / 2;
    for (const cx of pCxs) edges.push({ type: "pc", x1: cx, y1: pBotY, x2: cx, y2: midY });
    if (pCxs.length > 1) edges.push({ type: "pc", x1: Math.min(...pCxs), y1: midY, x2: Math.max(...pCxs), y2: midY });
    edges.push({ type: "pc", x1: hubX, y1: midY, x2: hubX, y2: cBarY });
    const cbL = Math.min(...cCxs, hubX), cbR = Math.max(...cCxs, hubX);
    edges.push({ type: "pc", x1: cbL, y1: cBarY, x2: cbR, y2: cBarY });
    for (const cx of cCxs) edges.push({ type: "pc", x1: cx, y1: cBarY, x2: cx, y2: cTopY });
  }
  (relationships || []).forEach(rel => {
    if (STRUCTURAL.has(rel.type)) return;
    const pa = positions.get(rel.fromId), pb = positions.get(rel.toId);
    if (!pa || !pb) return;
    edges.push({ type: "custom", x1: pa.x + NW / 2, y1: pa.y + NH / 2, x2: pb.x + NW / 2, y2: pb.y + NH / 2, color: REL_TYPES.find(r => r.id === rel.type)?.color ?? "#94a3b8" });
  });
  return edges;
}

// ── 3. Detail Panel Component ──────────────────────────────
function CharPanel({ char, characters, relationships, addRelationship, removeRelationship, onClose }) {
  const [linkType, setLinkType] = useState(LINK_TYPES[0]?.id ?? "");
  const [linkTo,   setLinkTo]   = useState("");

  const myLinks = (relationships || []).filter(
    r => !STRUCTURAL.has(r.type) && (r.fromId === char.id || r.toId === char.id)
  );
  const find  = id => characters.find(c => c.id === id);
  const others = characters.filter(c => c.id !== char.id);

  const handleAdd = () => {
    if (!linkTo || !linkType) return;
    addRelationship?.(char.id, linkTo, linkType);
    setLinkTo("");
  };

  return (
    <div className="w-60 bg-slate-900 border-l border-slate-700/60 flex flex-col flex-shrink-0 overflow-hidden">
      <div className="flex items-center justify-between px-3 py-2.5 border-b border-slate-700/60">
        <div className="min-w-0">
          <p className="text-sm font-semibold text-slate-200 truncate">{char.name}</p>
          {char.familyGroup && <p className="text-xs text-slate-500 truncate">{char.familyGroup}</p>}
        </div>
        <button onClick={onClose} className="text-slate-500 hover:text-slate-300 text-xl leading-none ml-2 flex-shrink-0">×</button>
      </div>
      <div className="flex-1 overflow-y-auto p-3 space-y-4 text-xs">
        {char.role && (
          <div>
            <p className="text-slate-500 uppercase tracking-wider mb-1">Role</p>
            <p className="text-slate-300">{char.role}</p>
          </div>
        )}
        {myLinks.length > 0 && (
          <div>
            <p className="text-slate-500 uppercase tracking-wider mb-2">Links</p>
            <div className="space-y-1.5">
              {myLinks.map(rel => {
                const otherId = rel.fromId === char.id ? rel.toId : rel.fromId;
                const other   = find(otherId);
                const rt      = REL_TYPES.find(r => r.id === rel.type);
                return (
                  <div key={rel.id} className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: rt?.color ?? "#94a3b8" }} />
                      <span className="text-slate-400 flex-shrink-0">{rt?.label ?? rel.type}</span>
                      <span className="text-slate-200 truncate">{other?.name ?? "?"}</span>
                    </div>
                    <button onClick={() => removeRelationship?.(rel.id)} className="text-slate-600 hover:text-red-400 flex-shrink-0 text-base leading-none">×</button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
        <div>
          <p className="text-slate-500 uppercase tracking-wider mb-2">Add Link</p>
          <div className="space-y-1.5">
            <select value={linkType} onChange={e => setLinkType(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1.5 text-slate-200 text-xs">
              {LINK_TYPES.map(r => <option key={r.id} value={r.id}>{r.label}</option>)}
            </select>
            <select value={linkTo} onChange={e => setLinkTo(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1.5 text-slate-200 text-xs">
              <option value="">— Select character —</option>
              {others.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <button onClick={handleAdd} disabled={!linkTo} className="w-full py-1.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-900 font-semibold rounded">Add link</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── 4. Main Component ──────────────────────────────────────
export default function FamilyTree({ characters = [], relationships = [], addRelationship, removeRelationship }) {
  const [zoom, setZoom] = useState(1);
  const [selected, setSelected] = useState(null);
  const [showColors, setShowColors] = useState(false);
  const [groupColors, setGroupColors] = useState(() => loadPref("nf_treeColors", {}));
  const [bgColor, setBgColor] = useState(() => loadPref("nf_bgColor", "#020617"));

  const [dragOffsets, setDragOffsets] = useState({});
  const [groupOffsets, setGroupOffsets] = useState({});
  const activeDrag = useRef(null);

  const { positions, spousePairs, groupMeta } = useMemo(
    () => buildLayout(characters, dragOffsets, groupOffsets),
    [characters, dragOffsets, groupOffsets]
  );
  
  const edges = useMemo(
    () => buildEdges(characters, positions, spousePairs, relationships),
    [characters, positions, spousePairs, relationships]
  );

  const canvasBounds = useMemo(() => {
    if (!positions.size) return { w: 1000, h: 1000 };
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    positions.forEach(p => {
      minX = Math.min(minX, p.x);
      maxX = Math.max(maxX, p.x + NW);
      minY = Math.min(minY, p.y);
      maxY = Math.max(maxY, p.y + NH);
    });
    // Add margin so things aren't right on the edge
    return { 
      w: (maxX + PAD * 2) * zoom, 
      h: (maxY + PAD * 2) * zoom 
    };
  }, [positions, zoom]);

  useEffect(() => { localStorage.setItem("nf_bgColor", JSON.stringify(bgColor)); }, [bgColor]);

  const startDrag = (e, type, id) => {
    e.stopPropagation();
    const current = type === 'node' ? (dragOffsets[id] || { x: 0, y: 0 }) : (groupOffsets[id] || { x: 0, y: 0 });
    activeDrag.current = { type, id, startX: e.clientX, startY: e.clientY, initX: current.x, initY: current.y };
    if (type === 'node') setSelected(id);
  };

  const onPointerMove = (e) => {
    if (!activeDrag.current) return;
    const { type, id, startX, startY, initX, initY } = activeDrag.current;
    const dx = (e.clientX - startX) / zoom;
    const dy = (e.clientY - startY) / zoom;
    if (type === 'node') setDragOffsets(prev => ({ ...prev, [id]: { x: initX + dx, y: initY + dy } }));
    else setGroupOffsets(prev => ({ ...prev, [id]: { x: initX + dx, y: initY + dy } }));
  };

  const endDrag = () => { activeDrag.current = null; };
  const resetAll = () => { setDragOffsets({}); setGroupOffsets({}); setZoom(1); };

  const saveGroupColor = (name, color) => {
    const next = { ...groupColors, [name]: color };
    setGroupColors(next);
    localStorage.setItem("nf_treeColors", JSON.stringify(next));
  };

  if (!characters.length) {
    return (
      <div className="h-full flex items-center justify-center text-slate-600">
        <p>Add characters to build the tree.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full select-none overflow-hidden" style={{ backgroundColor: bgColor }}>
      <div className="flex items-center gap-3 px-4 py-2 bg-slate-900/80 border-b border-white/5 flex-shrink-0 z-10 backdrop-blur-md">
        <div className="flex items-center gap-1">
          <button onClick={() => setZoom(z => Math.max(0.1, +(z - 0.1).toFixed(2)))} className="w-8 h-8 bg-white/5 rounded text-slate-300">－</button>
          <span className="text-xs text-slate-400 w-12 text-center tabular-nums">{Math.round(zoom * 100)}%</span>
          <button onClick={() => setZoom(z => Math.min(3, +(z + 0.1).toFixed(2)))} className="w-8 h-8 bg-white/5 rounded text-slate-300">＋</button>
        </div>
        <div className="w-px h-4 bg-white/10 mx-1" />
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-500 uppercase font-bold">BG</span>
          <input type="color" value={bgColor} onChange={(e) => setBgColor(e.target.value)} className="w-6 h-6 rounded bg-transparent cursor-pointer" />
        </div>
        <button onClick={() => setShowColors(!showColors)} className="text-xs px-3 py-1.5 border border-white/10 text-slate-400 hover:text-white rounded transition-colors">Clans</button>
        <button onClick={resetAll} className="text-xs text-slate-500 hover:text-red-400 ml-1">Reset</button>
      </div>

      <div className="flex flex-1 overflow-hidden" onPointerMove={onPointerMove} onPointerUp={endDrag} onPointerLeave={endDrag}>
        
        {showColors && (
          <div className="w-52 bg-slate-900/90 border-r border-white/5 overflow-y-auto p-3 space-y-2 z-20">
            {groupMeta.map(g => (
              <label key={g.name} className="flex items-center gap-2 cursor-pointer">
                <input type="color" value={groupColors[g.name] || PALETTE[0]} onChange={(e) => saveGroupColor(g.name, e.target.value)} className="w-5 h-5 rounded bg-transparent" />
                <span className="text-xs text-slate-300 truncate">{g.name}</span>
              </label>
            ))}
          </div>
        )}

        <div className="flex-1 overflow-auto">
          <svg width={canvasBounds.w} height={canvasBounds.h} style={{ overflow: 'visible' }}>
            <g transform={`scale(${zoom})`}>
              {groupMeta.map(g => {
                const col = groupColors[g.name] || PALETTE[0];
                return (
                  <g key={g.name}>
                    <rect x={g.x + 6} y={g.y - 32} width={g.w - 6} height={g.h + 52} rx={16} fill="none" stroke={col} strokeOpacity={0.2} strokeWidth={2} strokeDasharray="6 4" />
                    <text x={g.x + PAD} y={g.y - 12} fill={col} fillOpacity={0.7} fontSize={10} fontWeight="900" className="cursor-move tracking-widest" onPointerDown={(e) => startDrag(e, 'group', g.name)}>:: {g.name.toUpperCase()}</text>
                  </g>
                );
              })}
              {edges.map((e, i) => (
                <line key={i} x1={e.x1} y1={e.y1} x2={e.x2} y2={e.y2} stroke={e.color || (e.type === 'spouse' ? "#f59e0b" : "#ffffff")} strokeWidth={1.2} strokeDasharray={e.type !== 'pc' ? "4 3" : "0"} strokeOpacity={e.type === 'custom' ? 0.3 : 0.2} />
              ))}
              {characters.map(c => {
                const p = positions.get(c.id);
                if (!p) return null;
                const col = groupColors[c.familyGroup?.trim()] || PALETTE[0];
                const isSel = selected === c.id;
                return (
                  <g key={c.id} onPointerDown={(e) => startDrag(e, 'node', c.id)} className="cursor-grab active:cursor-grabbing">
                    <rect x={p.x} y={p.y} width={NW} height={NH} rx={10} fill="#0f172a" stroke={isSel ? "#f59e0b" : col} strokeWidth={isSel ? 3 : 1.5} />
                    <circle cx={p.x + 26} cy={p.y + NH / 2} r={17} fill={col} fillOpacity={0.1} />
                    <text x={p.x + 26} y={p.y + NH / 2 + 5} textAnchor="middle" fill={col} fontSize={14} fontWeight="900">{c.name?.charAt(0)}</text>
                    <text x={p.x + 51} y={p.y + 26} fill="#f8fafc" fontSize={12} fontWeight="700">{c.name}</text>
                    <text x={p.x + 51} y={p.y + 42} fill="#64748b" fontSize={10}>{c.role?.slice(0, 18)}</text>
                  </g>
                );
              })}
            </g>
          </svg>
        </div>
        {selected && <CharPanel char={characters.find(c => c.id === selected)} characters={characters} relationships={relationships} onClose={() => setSelected(null)} />}
      </div>
    </div>
  );
}