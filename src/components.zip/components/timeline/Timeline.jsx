import { useState, useRef } from 'react'
import Modal from '../shared/Modal'

const INPUT = 'w-full bg-slate-900 border border-slate-600 rounded px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-amber-500 placeholder:text-slate-600'
const LABEL = 'block text-xs text-slate-400 mb-1.5'

// Parse any date string containing a number for chronological sorting
function parseDate(str) {
  if (!str) return Infinity
  const m = str.match(/-?\d+/)
  return m ? parseInt(m[0], 10) : Infinity
}

// ─── Event form ───────────────────────────────────────────────────────────────

function EventForm({ initial, characters, onSave, onCancel }) {
  const [form, setForm] = useState({
    title: initial?.title ?? '',
    date: initial?.date ?? '',
    description: initial?.description ?? '',
    tags: initial?.tags ?? [],
    linkedCharacters: initial?.linkedCharacters ?? [],
  })
  const [tagInput, setTagInput] = useState('')
  const field = (key) => (e) => setForm(p => ({ ...p, [key]: e.target.value }))
  const addTag = (e) => {
    if ((e.key === 'Enter' || e.key === ',') && tagInput.trim()) {
      e.preventDefault()
      const tag = tagInput.trim().replace(/,$/, '')
      if (tag && !form.tags.includes(tag)) setForm(p => ({ ...p, tags: [...p.tags, tag] }))
      setTagInput('')
    }
  }
  const toggleChar = (id) => setForm(p => ({
    ...p,
    linkedCharacters: p.linkedCharacters.includes(id)
      ? p.linkedCharacters.filter(x => x !== id)
      : [...p.linkedCharacters, id],
  }))

  return (
    <form onSubmit={(e) => { e.preventDefault(); if (form.title.trim()) onSave(form) }} className="space-y-4">
      <div>
        <label className={LABEL}>Event title *</label>
        <input value={form.title} onChange={field('title')} className={INPUT} required />
      </div>
      <div>
        <label className={LABEL}>Date / Time</label>
        <input value={form.date} onChange={field('date')} placeholder="e.g. Year 312, 3rd Month, -50 BC" className={INPUT} />
      </div>
      <div>
        <label className={LABEL}>Description</label>
        <textarea value={form.description} onChange={field('description')} rows={6}
          className={INPUT + ' resize-none'} placeholder="What happened?" />
      </div>
      <div>
        <label className={LABEL}>Tags</label>
        {form.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-1.5">
            {form.tags.map(t => (
              <span key={t} className="inline-flex items-center gap-1 bg-slate-700 rounded px-2 py-0.5 text-xs text-slate-300">
                {t}
                <button type="button" onClick={() => setForm(p => ({ ...p, tags: p.tags.filter(x => x !== t) }))}
                  className="text-slate-500 hover:text-slate-100">×</button>
              </span>
            ))}
          </div>
        )}
        <input value={tagInput} onChange={e => setTagInput(e.target.value)} onKeyDown={addTag}
          placeholder="Type a tag and press Enter" className={INPUT} />
      </div>
      {characters.length > 0 && (
        <div>
          <label className={LABEL}>Linked characters</label>
          <div className="max-h-32 overflow-y-auto bg-slate-900 border border-slate-600 rounded p-2 space-y-1.5">
            {characters.map(c => (
              <label key={c.id} className="flex items-center gap-2 text-sm cursor-pointer text-slate-300 hover:text-slate-100">
                <input type="checkbox" checked={form.linkedCharacters.includes(c.id)} onChange={() => toggleChar(c.id)}
                  className="accent-amber-500" />
                {c.name}
              </label>
            ))}
          </div>
        </div>
      )}
      <div className="flex gap-2 pt-1 border-t border-slate-700">
        <button type="submit" className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold rounded text-sm transition-colors">Save</button>
        <button type="button" onClick={onCancel} className="px-4 py-2 text-slate-400 hover:text-slate-200 text-sm transition-colors">Cancel</button>
      </div>
    </form>
  )
}

// ─── Horizontal timeline ──────────────────────────────────────────────────────

const SPINE_Y     = 160   // vertical center of the SVG
const EV_SPACING  = 200   // horizontal pixels per event
const LEFT_PAD    = 80    // left padding before first event
const SVG_HEIGHT  = 320   // total SVG height
const DOT_R       = 7     // dot radius

export default function Timeline({ store }) {
  const { timeline, characters, addEvent, updateEvent, deleteEvent } = store
  const [search, setSearch] = useState('')
  const [expandedId, setExpandedId] = useState(null)
  const [cardPos, setCardPos] = useState({ x: 0, above: true })
  const [showForm, setShowForm] = useState(false)
  const [editTarget, setEditTarget] = useState(null)
  const svgRef = useRef(null)

  const filtered = timeline
    .filter(e =>
      e.title.toLowerCase().includes(search.toLowerCase()) ||
      (e.description || '').toLowerCase().includes(search.toLowerCase()) ||
      (e.date || '').toLowerCase().includes(search.toLowerCase())
    )
    .slice()
    .sort((a, b) => parseDate(a.date) - parseDate(b.date))

  const closeForm = () => { setShowForm(false); setEditTarget(null) }
  const handleSave = (data) => {
    if (editTarget) updateEvent(editTarget.id, data)
    else addEvent(data)
    closeForm()
  }
  const handleDelete = (id) => {
    if (!confirm('Delete this event?')) return
    deleteEvent(id)
    if (expandedId === id) setExpandedId(null)
  }
  const getCharName = (id) => characters.find(c => c.id === id)?.name

  const totalWidth = LEFT_PAD + filtered.length * EV_SPACING + 80

  const handleDotClick = (e, idx, evId) => {
    const above = idx % 2 === 0
    const x = LEFT_PAD + idx * EV_SPACING
    if (expandedId === evId) {
      setExpandedId(null)
    } else {
      setExpandedId(evId)
      setCardPos({ x, above })
    }
  }

  const expandedEvent = expandedId ? filtered.find(e => e.id === expandedId) : null
  const expandedIdx   = expandedId ? filtered.findIndex(e => e.id === expandedId) : -1

  return (
    <div className="h-full flex flex-col">
      {/* Toolbar */}
      <div className="px-5 py-3 border-b border-slate-700/60 flex items-center justify-between flex-shrink-0">
        <h2 className="text-sm font-semibold text-slate-200">Timeline</h2>
        <div className="flex items-center gap-3">
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search events…"
            className="bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-200 w-44 focus:outline-none focus:border-amber-500 placeholder:text-slate-600"
          />
          <button
            onClick={() => { setEditTarget(null); setShowForm(true) }}
            className="text-xs text-amber-400 hover:text-amber-300 border border-amber-500/30 hover:border-amber-400 px-3 py-1.5 rounded transition-colors"
          >
            + New Event
          </button>
        </div>
      </div>

      {/* Canvas */}
      <div className="flex-1 overflow-auto">
        {filtered.length === 0 ? (
          <div className="flex items-center justify-center h-full text-slate-700">
            <div className="text-center">
              <div className="text-5xl mb-3 opacity-60">⏳</div>
              <p className="text-sm">{timeline.length === 0 ? 'No events yet.' : 'No matches.'}</p>
            </div>
          </div>
        ) : (
          <div className="relative" style={{ minHeight: SVG_HEIGHT + 'px' }}>
            <svg
              ref={svgRef}
              width={totalWidth}
              height={SVG_HEIGHT}
              style={{ display: 'block', minWidth: '100%' }}
            >
              {/* Horizontal spine */}
              <line x1={LEFT_PAD - 20} y1={SPINE_Y} x2={totalWidth - 60} y2={SPINE_Y}
                stroke="#334155" strokeWidth="2" />

              {/* Arrow at the right end */}
              <polygon
                points={`${totalWidth - 54},${SPINE_Y - 7} ${totalWidth - 36},${SPINE_Y} ${totalWidth - 54},${SPINE_Y + 7}`}
                fill="#475569"
              />
              <text x={totalWidth - 30} y={SPINE_Y + 4} fill="#475569" fontSize="10" fontWeight="600">latest</text>

              {filtered.map((ev, idx) => {
                const x     = LEFT_PAD + idx * EV_SPACING
                const above = idx % 2 === 0
                const labelY = above ? SPINE_Y - 28 : SPINE_Y + 38
                const tickY1 = above ? SPINE_Y - DOT_R - 2 : SPINE_Y + DOT_R + 2
                const tickY2 = above ? SPINE_Y - 20 : SPINE_Y + 20
                const isExpanded = expandedId === ev.id

                return (
                  <g key={ev.id} onClick={(e) => handleDotClick(e, idx, ev.id)} style={{ cursor: 'pointer' }}>
                    {/* Tick mark */}
                    <line x1={x} y1={tickY1} x2={x} y2={tickY2} stroke="#475569" strokeWidth="1.5" />

                    {/* Glowing dot */}
                    <circle cx={x} cy={SPINE_Y} r={DOT_R + 4} fill={isExpanded ? '#f59e0b22' : 'transparent'} />
                    <circle cx={x} cy={SPINE_Y} r={DOT_R}
                      fill={isExpanded ? '#f59e0b' : '#1e293b'}
                      stroke={isExpanded ? '#fbbf24' : '#64748b'}
                      strokeWidth="2"
                    />
                    {isExpanded && <circle cx={x} cy={SPINE_Y} r={DOT_R - 2} fill="#fbbf24" opacity="0.6" />}

                    {/* Label */}
                    <text
                      x={x} y={labelY}
                      textAnchor="middle"
                      fill={isExpanded ? '#fbbf24' : '#94a3b8'}
                      fontSize="11"
                      fontWeight={isExpanded ? '600' : '400'}
                    >
                      {ev.title.length > 18 ? ev.title.slice(0, 17) + '…' : ev.title}
                    </text>

                    {/* Date below/above label */}
                    {ev.date && (
                      <text
                        x={x} y={above ? labelY - 14 : labelY + 14}
                        textAnchor="middle"
                        fill="#d97706"
                        fontSize="10"
                      >
                        {ev.date}
                      </text>
                    )}
                  </g>
                )
              })}
            </svg>

            {/* Floating detail card */}
            {expandedEvent && expandedIdx >= 0 && (() => {
              const x     = LEFT_PAD + expandedIdx * EV_SPACING
              const above = expandedIdx % 2 === 0
              const cardW = 260
              // Clamp so card stays inside the scrollable area
              const cardLeft = Math.max(8, x - cardW / 2)

              return (
                <div
                  className="absolute z-20 bg-slate-900 border border-slate-600 rounded-xl shadow-2xl p-4"
                  style={{
                    width: cardW,
                    left: cardLeft,
                    ...(above
                      ? { bottom: SVG_HEIGHT - SPINE_Y + DOT_R + 14 }
                      : { top: SPINE_Y + DOT_R + 14 }),
                  }}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <span className="font-semibold text-sm text-slate-100 leading-snug">{expandedEvent.title}</span>
                    <button onClick={() => setExpandedId(null)} className="text-slate-600 hover:text-slate-400 text-sm flex-shrink-0 leading-none mt-0.5">✕</button>
                  </div>
                  {expandedEvent.date && (
                    <div className="text-xs text-amber-400 mb-2">{expandedEvent.date}</div>
                  )}
                  {expandedEvent.description && (
                    <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap mb-2 max-h-32 overflow-y-auto">
                      {expandedEvent.description}
                    </p>
                  )}
                  {expandedEvent.linkedCharacters?.length > 0 && (
                    <div className="text-xs text-slate-500 mb-2">
                      <span className="uppercase tracking-wider">Characters: </span>
                      <span className="text-slate-400">
                        {expandedEvent.linkedCharacters.map(id => getCharName(id)).filter(Boolean).join(', ')}
                      </span>
                    </div>
                  )}
                  {expandedEvent.tags?.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {expandedEvent.tags.map(t => (
                        <span key={t} className="bg-slate-800 text-slate-400 text-xs px-1.5 py-0.5 rounded">{t}</span>
                      ))}
                    </div>
                  )}
                  <div className="flex gap-2 pt-2 border-t border-slate-700/60">
                    <button
                      onClick={() => { setEditTarget(expandedEvent); setShowForm(true); setExpandedId(null) }}
                      className="text-xs px-2.5 py-1 border border-slate-600 hover:border-amber-500 text-slate-400 hover:text-amber-400 rounded transition-colors"
                    >Edit</button>
                    <button
                      onClick={() => handleDelete(expandedEvent.id)}
                      className="text-xs px-2.5 py-1 border border-slate-700 hover:border-red-500 text-slate-500 hover:text-red-400 rounded transition-colors"
                    >Delete</button>
                  </div>
                </div>
              )
            })()}
          </div>
        )}
      </div>

      {showForm && (
        <Modal title={editTarget ? `Edit — ${editTarget.title}` : 'New Timeline Event'} onClose={closeForm} wide>
          <EventForm initial={editTarget} characters={characters} onSave={handleSave} onCancel={closeForm} />
        </Modal>
      )}
    </div>
  )
}
