import { useState } from 'react'
import Modal from '../shared/Modal'

const INPUT = 'w-full bg-slate-900 border border-slate-600 rounded px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-amber-500 placeholder:text-slate-600'
const LABEL = 'block text-xs text-slate-400 mb-1.5'

function HistoryForm({ initial, onSave, onCancel }) {
  const [form, setForm] = useState({
    title: initial?.title ?? '',
    era: initial?.era ?? '',
    dateRange: initial?.dateRange ?? '',
    content: initial?.content ?? '',
    tags: initial?.tags ?? [],
  })
  const [tagInput, setTagInput] = useState('')
  const field = (key) => (e) => setForm(p => ({ ...p, [key]: e.target.value }))
  const addTag = (e) => {
    if ((e.key === 'Enter' || e.key === ',') && tagInput.trim()) {
      e.preventDefault()
      const tag = tagInput.trim().replace(/,$/, '')
      if (tag && !form.tags.includes(tag)) setForm(p => ({ ...p, tags: [...p.tags, tag] }))
      setTagInput('')
    }
  }

  return (
    <form onSubmit={(e) => { e.preventDefault(); if (form.title.trim()) onSave(form) }} className="space-y-4">
      <div>
        <label className={LABEL}>Title *</label>
        <input value={form.title} onChange={field('title')} className={INPUT} required />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className={LABEL}>Era / Age</label>
          <input value={form.era} onChange={field('era')} placeholder="e.g. The Second Age" className={INPUT} />
        </div>
        <div>
          <label className={LABEL}>Date range</label>
          <input value={form.dateRange} onChange={field('dateRange')} placeholder="e.g. Years 100–500" className={INPUT} />
        </div>
      </div>
      <div>
        <label className={LABEL}>Content</label>
        <textarea value={form.content} onChange={field('content')} rows={10} className={INPUT + ' resize-none'} placeholder="Describe what happened during this period…" />
      </div>
      <div>
        <label className={LABEL}>Tags</label>
        {form.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-1.5">
            {form.tags.map(t => (
              <span key={t} className="inline-flex items-center gap-1 bg-slate-700 rounded px-2 py-0.5 text-xs text-slate-300">
                {t}
                <button type="button" onClick={() => setForm(p => ({ ...p, tags: p.tags.filter(x => x !== t) }))} className="text-slate-500 hover:text-slate-100">×</button>
              </span>
            ))}
          </div>
        )}
        <input value={tagInput} onChange={e => setTagInput(e.target.value)} onKeyDown={addTag} placeholder="Type a tag and press Enter" className={INPUT} />
      </div>
      <div className="flex gap-2 pt-1 border-t border-slate-700">
        <button type="submit" className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold rounded text-sm transition-colors">Save</button>
        <button type="button" onClick={onCancel} className="px-4 py-2 text-slate-400 hover:text-slate-200 text-sm transition-colors">Cancel</button>
      </div>
    </form>
  )
}

export default function WorldHistory({ store }) {
  const { worldHistory, addHistoryEntry, updateHistoryEntry, deleteHistoryEntry } = store
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const [editTarget, setEditTarget] = useState(null)

  const filtered = worldHistory.filter(h =>
    h.title.toLowerCase().includes(search.toLowerCase()) ||
    (h.era || '').toLowerCase().includes(search.toLowerCase()) ||
    (h.content || '').toLowerCase().includes(search.toLowerCase())
  )

  // Group by era
  const grouped = filtered.reduce((acc, h) => {
    const era = h.era || 'Unknown Era'
    if (!acc[era]) acc[era] = []
    acc[era].push(h)
    return acc
  }, {})

  const closeForm = () => { setShowForm(false); setEditTarget(null) }

  const handleSave = (data) => {
    if (editTarget) {
      updateHistoryEntry(editTarget.id, data)
      setSelected(prev => prev?.id === editTarget.id ? { ...prev, ...data } : prev)
    } else {
      const entry = addHistoryEntry(data)
      setSelected(entry)
    }
    closeForm()
  }

  const handleDelete = (id) => {
    if (!confirm('Delete this history entry?')) return
    deleteHistoryEntry(id)
    if (selected?.id === id) setSelected(null)
  }

  const liveSelected = selected ? worldHistory.find(h => h.id === selected.id) : null

  return (
    <div className="flex h-full">
      <div className="w-60 bg-slate-900/40 border-r border-slate-700/60 flex flex-col flex-shrink-0">
        <div className="p-3 border-b border-slate-700/60 space-y-2">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-200">World History</h2>
            <button onClick={() => { setEditTarget(null); setShowForm(true) }} className="text-xs text-amber-400 hover:text-amber-300 border border-amber-500/30 hover:border-amber-400 px-2 py-1 rounded transition-colors">
              + New
            </button>
          </div>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search…" className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-amber-500 placeholder:text-slate-600" />
        </div>
        <div className="flex-1 overflow-y-auto">
          {filtered.length === 0 && (
            <p className="text-slate-600 text-xs p-4 text-center">{worldHistory.length === 0 ? 'No entries yet.' : 'No matches.'}</p>
          )}
          {Object.entries(grouped).map(([era, entries]) => (
            <div key={era}>
              <div className="px-3 py-1.5 text-xs font-medium text-amber-500/60 uppercase tracking-wider border-b border-slate-800/60 bg-slate-900/50 sticky top-0">
                {era}
              </div>
              {entries.map(h => (
                <button
                  key={h.id}
                  onClick={() => setSelected(worldHistory.find(x => x.id === h.id))}
                  className={`w-full text-left px-3 py-2.5 border-b border-slate-800/40 hover:bg-slate-800/60 transition-colors ${liveSelected?.id === h.id ? 'bg-slate-800/60 border-l-2 border-l-amber-500 pl-2.5' : ''}`}
                >
                  <div className="text-sm font-medium text-slate-200 truncate">{h.title}</div>
                  {h.dateRange && <div className="text-xs text-slate-500 mt-0.5">{h.dateRange}</div>}
                </button>
              ))}
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        {!liveSelected ? (
          <div className="h-full flex items-center justify-center text-slate-700">
            <div className="text-center">
              <div className="text-5xl mb-3 opacity-60">📜</div>
              <p className="text-sm">Select an entry or create one</p>
            </div>
          </div>
        ) : (
          <div className="max-w-2xl">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h2 className="text-2xl font-bold text-slate-100">{liveSelected.title}</h2>
                <div className="flex items-center gap-3 mt-1.5">
                  {liveSelected.era && <span className="text-xs text-amber-400">{liveSelected.era}</span>}
                  {liveSelected.dateRange && <span className="text-xs text-slate-400">{liveSelected.dateRange}</span>}
                </div>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <button onClick={() => { setEditTarget(liveSelected); setShowForm(true) }} className="text-sm px-3 py-1.5 border border-slate-600 hover:border-amber-500 text-slate-300 hover:text-amber-400 rounded transition-colors">Edit</button>
                <button onClick={() => handleDelete(liveSelected.id)} className="text-sm px-3 py-1.5 border border-slate-700 hover:border-red-500 text-slate-500 hover:text-red-400 rounded transition-colors">Delete</button>
              </div>
            </div>
            {liveSelected.content && (
              <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap mb-4">{liveSelected.content}</p>
            )}
            {liveSelected.tags?.length > 0 && (
              <div className="flex flex-wrap gap-1 pt-3 border-t border-slate-700/60">
                {liveSelected.tags.map(t => (
                  <span key={t} className="bg-slate-800 border border-slate-700 text-slate-400 text-xs px-2 py-0.5 rounded">{t}</span>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {showForm && (
        <Modal title={editTarget ? `Edit — ${editTarget.title}` : 'New History Entry'} onClose={closeForm} wide>
          <HistoryForm initial={editTarget} onSave={handleSave} onCancel={closeForm} />
        </Modal>
      )}
    </div>
  )
}
